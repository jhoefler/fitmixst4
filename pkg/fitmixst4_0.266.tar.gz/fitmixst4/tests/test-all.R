library(testthat)
test_check("fitmixst4")